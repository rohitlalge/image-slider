let currentSlide = 0;
const slides = document.querySelector('.slides');
const totalSlides = document.querySelectorAll('.slide').length;
const dotsContainer = document.querySelector('.dots');

// Create dots dynamically
for (let i = 0; i < totalSlides; i++) {
    const dot = document.createElement('span');
    dot.classList.add('dot');
    dot.addEventListener('click', () => goToSlide(i));
    dotsContainer.appendChild(dot);
}

const dots = document.querySelectorAll('.dot');

function showSlide(index) {
    slides.style.transform = `translateX(-${index * 100}%)`;

    dots.forEach((dot, i) => {
        dot.classList.remove('active');
        if (i === index) {
            dot.classList.add('active');
        }
    });
}
let slideInterval = setInterval(nextSlide, 4000);

document.querySelector(".slider").addEventListener("mouseenter", function() {
    clearInterval(slideInterval); // Pause auto-slide
});

document.querySelector(".slider").addEventListener("mouseleave", function() {
    slideInterval = setInterval(nextSlide, 4000); // Resume auto-slide
});

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    showSlide(currentSlide);
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    showSlide(currentSlide);
}

function goToSlide(index) {
    currentSlide = index;
    showSlide(currentSlide);
}

// Auto-slide every 3 seconds
setInterval(nextSlide, 40000); // 2000ms (2 seconds)


showSlide(currentSlide);
